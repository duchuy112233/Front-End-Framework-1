export interface Register {
  name: string;
  email: string;
}
